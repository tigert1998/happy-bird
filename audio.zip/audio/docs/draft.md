[opengl中不中断draw 循环播放声音-StackOverflow](https://stackoverflow.com/questions/42892254/playing-audio-without-freezing-draw-loop-in-opengl) 

[上述需求在OpenAL中的实现-StackOverflow](https://stackoverflow.com/questions/15064742/play-stream-in-openal-library)

[win平台的函数](https://msdn.microsoft.com/en-us/library/windows/desktop/dd743680(v=vs.85).aspx)





