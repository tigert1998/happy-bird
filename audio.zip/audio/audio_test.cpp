#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<string>
#include<cstdint>
#include<future>
#include<iostream>
#include<windows.h>
#include<mmreg.h>
#include "mmsystem.h"//��������ͷ�ļ�
#pragma comment(lib,"winmm.lib")//��������ͷ�ļ��� 
#define FOURCC_WAVE mmioFOURCC('W', 'A', 'V', 'E')
#define FOURCC_FMT mmioFOURCC('f', 'm', 't', ' ')
#define FOURCC_DATA mmioFOURCC('d', 'a', 't', 'a')

DWORD CalculateWaveLength(LPTSTR FileName)
{
	MMIOINFO mmioinfo = { 0 };
	MMCKINFO mmckinfoRIFF = { 0 };
	MMCKINFO mmckinfoFMT = { 0 };
	MMCKINFO mmckinfoDATA = { 0 };
	MMRESULT mmr;
	WAVEFORMATEXTENSIBLE waveFormat = { 0 };
	HMMIO mmh = mmioOpen(FileName, &mmioinfo, MMIO_DENYNONE | MMIO_READ);
	if (mmh == NULL)
	{
		return 0;
	}
	mmr = mmioDescend(mmh, &mmckinfoRIFF, NULL, 0);
	if (mmr != MMSYSERR_NOERROR && mmckinfoRIFF.ckid != FOURCC_RIFF)
	{
		return 0;
	}
	if (mmckinfoRIFF.fccType != FOURCC_WAVE)
	{
		return 0;
	}
	mmckinfoFMT.ckid = FOURCC_FMT;
	mmr = mmioDescend(mmh, &mmckinfoFMT, &mmckinfoRIFF, MMIO_FINDCHUNK);
	if (mmr != MMSYSERR_NOERROR)
	{
		return 0;
	}
	if (mmckinfoFMT.cksize >= sizeof(WAVEFORMAT))
	{
		LONG readLength = mmckinfoFMT.cksize;
		if (mmckinfoFMT.cksize >= sizeof(waveFormat))
		{
			readLength = sizeof(waveFormat);
		}
		if (readLength != mmioRead(mmh, (char *)&waveFormat, readLength))
		{
			return 0;
		}
	}
	if (waveFormat.Format.wFormatTag != WAVE_FORMAT_PCM)
	{
		return 0;
	}
	// Pop back up a level
	mmr = mmioAscend(mmh, &mmckinfoFMT, 0);
	if (mmr != MMSYSERR_NOERROR)
	{
		return 0;
	}
	// Now read the data section.
	mmckinfoDATA.ckid = FOURCC_DATA;
	mmr = mmioDescend(mmh, &mmckinfoDATA, &mmckinfoRIFF, MMIO_FINDCHUNK);
	if (mmr != MMSYSERR_NOERROR)
	{
		printf("Unable to find FMT section in RIFF file, possible file format error: %x\n", mmr);
		exit(1);
	}
	// Close the handle, we're done.
	mmr = mmioClose(mmh, 0);
	//
	// We now have all the info we need to calculate the file size. Use 64bit math 
	// to avoid potential rounding issues.
	//
	LONGLONG fileLengthinMS = mmckinfoDATA.cksize * 1000;
	fileLengthinMS /= waveFormat.Format.nAvgBytesPerSec;
	return fileLengthinMS;
}





